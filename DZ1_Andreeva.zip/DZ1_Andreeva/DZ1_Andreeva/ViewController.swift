//
//  ViewController.swift
//  DZ1_Andreeva
//
//  Created by Юлия Андреева on 24.10.2020.
//  Copyright © 2020 IULIIA ANDREEVA. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var MyScrollView: UIScrollView!
    @IBOutlet weak var MyLabel: UILabel!
    
    
    @IBOutlet weak var MyLogin: UILabel!
    @IBOutlet weak var MyTextLogin: UITextField!
    @IBOutlet weak var MyTextPassword: UITextField!
    @IBOutlet weak var MyPassword: UILabel!
    
    // Когда клавиатура появляется
    func keyboardWasShown(notification: Notification) {
        
        // Получаем размер клавиатуры
        let info = notification.userInfo! as NSDictionary
        let kbSize = (info.value(forKey: UIResponder.keyboardFrameEndUserInfoKey) as! NSValue).cgRectValue.size
        let contentInsets = UIEdgeInsets(top: 0.0, left: 0.0, bottom: kbSize.height, right: 0.0)
        
        // Добавляем отступ внизу UIScrollView, равный размеру клавиатуры
        self.MyScrollView?.contentInset = contentInsets
        MyScrollView?.scrollIndicatorInsets = contentInsets
    }
    
    //Когда клавиатура исчезает
    @objc func keyboardWillBeHidden(notification: Notification) {
        // Устанавливаем отступ внизу UIScrollView, равный 0
        let contentInsets = UIEdgeInsets.zero
        MyScrollView?.contentInset = contentInsets
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        func hideKeyboard() {
            self.MyScrollView?.endEditing(true)
        }
        // Подписываемся на два уведомления: одно приходит при появлении клавиатуры
        NotificationCenter.default.addObserver(self, selector: #selector(getter: self.MyTextPassword), name: UIResponder.keyboardWillShowNotification, object: nil)
        // Второе — когда она пропадает
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillBeHidden(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
        
        func viewWillDisappear(_ animated: Bool) {
            super.viewWillDisappear(animated)
            
            NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
            NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
        }
        
        func viewDidLoad() {
            super.viewDidLoad()
            
            // Жест нажатия
            let hideKeyboardGesture = UITapGestureRecognizer(target: self, action: (hideKeyboard),
                                                             // Присваиваем его UIScrollVIew
                MyScrollView?.addGestureRecognizer(hideKeyboardGesture))
            
            func loginButtonPressed(_ sender: Any) {
                // Получаем текст логина
                let login = MyTextLogin.text!
                // Получаем текст-пароль
                let password = MyTextPassword.text!
                
                // Проверяем, верны ли они
                if login == "admin" && password == "123456" {
                    print("успешная авторизация")
                } else {
                    print("неуспешная авторизация")
                    
                }
            }
            func MyButton(_ sender: Any) {
                print("Пользователь нажал кнопку")    }
        }
    }
}


